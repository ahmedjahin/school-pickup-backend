class User {
  final int id;
  final String phone;
  final String role;

  User({required this.id, required this.phone, required this.role});

  factory User.fromJson(Map<String, dynamic> json) {
    return User(id: json['id'], phone: json['phone'], role: json['role']);
  }
}