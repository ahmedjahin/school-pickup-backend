import 'package:flutter/material.dart';
import '../services/api_service.dart';

class AuthProvider extends ChangeNotifier {
  final ApiService api = ApiService();
  String? token;

  Future<bool> login(String phone, String password) async {
    token = await api.login(phone, password);
    if (token != null) { notifyListeners(); return true; }
    return false;
  }

  Future<bool> register(Map<String, dynamic> data) async {
    final res = await api.register(data);
    return res['success'] ?? false;
  }
}