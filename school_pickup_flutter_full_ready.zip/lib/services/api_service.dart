import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiService {
  // IP المعدل للاتصال بالـ Backend على محاكي Android
  final String baseUrl = 'http://10.0.2.2:3000/api';
  final storage = FlutterSecureStorage();

  Future<Map<String, dynamic>> register(Map<String, dynamic> body) async {
    final res = await http.post(Uri.parse('$baseUrl/auth/register'), headers: {'Content-Type': 'application/json'}, body: jsonEncode(body));
    return jsonDecode(res.body);
  }

  Future<String?> login(String phone, String password) async {
    final res = await http.post(Uri.parse('$baseUrl/auth/login'), headers: {'Content-Type': 'application/json'}, body: jsonEncode({'phone': phone, 'password': password}));
    final data = jsonDecode(res.body);
    if (data['access_token'] != null) {
      await storage.write(key: 'jwt', value: data['access_token']);
      return data['access_token'];
    }
    return null;
  }

  Future<Map<String, dynamic>> createPickup(int studentId, int schoolId, {int? vehicleId}) async {
    final token = await storage.read(key: 'jwt');
    final res = await http.post(Uri.parse('$baseUrl/pickup/intent'), headers: {'Content-Type': 'application/json','Authorization': 'Bearer $token'}, body: jsonEncode({'studentId': studentId,'schoolId': schoolId,'vehicleId': vehicleId}));
    return jsonDecode(res.body);
  }

  Future<List<dynamic>> getQueue(int schoolId) async {
    final token = await storage.read(key: 'jwt');
    final res = await http.get(Uri.parse('$baseUrl/pickup/queue/$schoolId'), headers: {'Authorization': 'Bearer $token'});
    return jsonDecode(res.body);
  }
}