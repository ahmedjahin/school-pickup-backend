class PickupRequest {
  final int id;
  final int studentId;
  final int parentId;
  final String state;

  PickupRequest({required this.id, required this.studentId, required this.parentId, required this.state});

  factory PickupRequest.fromJson(Map<String, dynamic> json) {
    return PickupRequest(
      id: json['id'],
      studentId: json['student_id'],
      parentId: json['parent_id'],
      state: json['state'],
    );
  }
}